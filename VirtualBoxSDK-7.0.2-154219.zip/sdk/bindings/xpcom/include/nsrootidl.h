/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM /home/vbox/tinderbox/sdk/src/libs/xpcom18a4/xpcom/base/nsrootidl.idl
 */

#ifndef __gen_nsrootidl_h__
#define __gen_nsrootidl_h__
/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nscore.h"
#include "prtime.h"
/*
 * Forward declarations for new string types
 */
class nsAString;
class nsACString;
/* 
 * Start commenting out the C++ versions of the below in the output header
 */
#if 0
/**
 * Root idl declarations to be used by all.
 * @status FROZEN
 */
typedef PRBool PRBool;

typedef PRUint8 PRUint8;

typedef PRUint16 PRUint16;

typedef PRUint16 PRUnichar;

typedef PRUint32 PRUint32;

typedef PRUint64 PRUint64;

typedef PRUint64 PRTime;

typedef PRInt16 PRInt16;

typedef PRInt32 PRInt32;

typedef PRInt64 PRInt64;

typedef PRUint32 nsrefcnt;

typedef PRUint32 nsresult;

typedef PRUint32 size_t;

/* 
 * End commenting out the C++ versions of the above in the output header
 */
#endif

#endif /* __gen_nsrootidl_h__ */
